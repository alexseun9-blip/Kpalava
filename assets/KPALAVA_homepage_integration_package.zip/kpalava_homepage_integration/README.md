# KPALAVA! approved homepage asset package

This package contains the original generated visual assets and a responsive, clickable homepage reference.

## Files
- `assets/kpalava-logo.webp` — optimized standalone dramatic logo.
- `assets/kpalava-logo-original.png` — original logo artwork.
- `assets/kpalava-home-reference.webp` — optimized exact approved homepage artwork.
- `assets/kpalava-home-reference-original.png` — original 1024×1536 screenshot.
- `index.html` — standalone preview with transparent clickable hotspots over the approved artwork.

## Preview
Open `index.html` in a browser. The image is the exact approved generated home-screen artwork. Hotspots are provided for menu, wallet, notifications, Play Now, Continue Playing, See All, all four story cards and all five bottom-navigation items.

The preview emits a `kpalava:navigate` browser event with `{ action }` for each click. The production app can listen for this event and connect each action to its existing screen router.

## Production integration
Copy the `assets/` directory into the repository's existing `assets/` folder. Use `kpalava-home-reference.webp` as the homepage artwork and `kpalava-logo.webp` wherever the standalone logo is needed. The generated screenshot already includes the logo and exact icons, so do not overlay duplicate CSS logo text or duplicate iconography on top of the screenshot.

Important: this package is prepared for repository integration; it does not itself deploy to GitHub Pages.
